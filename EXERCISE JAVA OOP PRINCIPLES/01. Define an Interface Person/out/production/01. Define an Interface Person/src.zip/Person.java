public interface Person {

    String getName();
    void setName(String newName);
    int getAge();
    void setAge(int newAge);
}
