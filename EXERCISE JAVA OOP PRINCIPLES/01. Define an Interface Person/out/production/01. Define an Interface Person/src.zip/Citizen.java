public class Citizen implements Person {
    private String name;
    private int age;

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setName(String newName) {
        this.name = newName;
    }

    @Override
    public int getAge() {
        return this.age;
    }

    @Override
    public void setAge(int newAge) {
        this.age = newAge;
    }

    public Citizen(String name, int age){
        this.name = name;
        this.age = age;
    }
}
