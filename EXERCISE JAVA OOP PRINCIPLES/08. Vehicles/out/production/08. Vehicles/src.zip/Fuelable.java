public interface Fuelable {
    void refill(Double liters);
}
