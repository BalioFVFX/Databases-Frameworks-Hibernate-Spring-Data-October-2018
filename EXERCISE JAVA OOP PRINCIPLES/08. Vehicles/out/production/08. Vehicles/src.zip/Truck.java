import java.text.DecimalFormat;

public class Truck extends Vehicle {
    @Override
    public void refill(Double liters) {
        this.fuelQuantity += liters * 0.95;
    }

    @Override
    public boolean travel(Double distance) {
        if(super.travel(distance)){
            DecimalFormat formatter = new DecimalFormat("###.#");
            System.out.printf("Truck travelled %s km\n", formatter.format(distance));
            return true;
        }
        System.out.println("Truck needs refueling");
        return false;
    }

    public Truck(Double fuelQuantity, Double fuelConsumption) {
        super(fuelQuantity, fuelConsumption + 1.6);
    }
}
