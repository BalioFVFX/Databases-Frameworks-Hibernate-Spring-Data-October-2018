public interface Browsable {
    void browse(String url);
}
