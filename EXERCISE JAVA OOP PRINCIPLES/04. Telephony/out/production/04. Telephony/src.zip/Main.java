import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] phoneNumbers = scanner.nextLine().split(" ");
        String[] urls = scanner.nextLine().split(" ");
        Smartphone smartphone = new Smartphone();

        for (int i = 0; i < phoneNumbers.length; i++) {
            smartphone.call(phoneNumbers[i]);
        }

        for (int i = 0; i < urls.length; i++) {
            smartphone.browse(urls[i]);
        }
    }
}
