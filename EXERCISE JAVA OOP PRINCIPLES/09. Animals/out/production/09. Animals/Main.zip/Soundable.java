public interface Soundable {
    void produceSound();
}
