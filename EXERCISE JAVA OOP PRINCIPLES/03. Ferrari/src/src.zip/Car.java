public interface Car {
    String useBreaks();
    String pushTheGas();
    String getModel();

}
